package com.rabbit.consumer.consumertest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
